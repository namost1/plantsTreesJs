import express from 'express';
import __dirname from './util/rootpath.js';
import path from 'path';

const app = express();
app.use(express.json());

app.get('/', (req, res) => {
    res.send('<h1>Welcome to the Plants API!</h1>');
});

app.get('/weboldal', (req, res) => {
    res.sendFile("./views/index.html", { root: __dirname });
});

app.get('/flowers', (req, res) => {
    const flowers = [
        { name: "Tulip", category: "Spring Flower" },
        { name: "Rose", category: "Perennial" },
        { name: "Daisy", category: "Wildflower" }
    ];
    res.json(flowers);
});

app.get('/trees', (req, res) => {
    const trees = [
        { name: "Oak", category: "Deciduous" },
        { name: "Pine", category: "Evergreen" },
        { name: "Birch", category: "Deciduous" }
    ];
    res.json(trees);
});


app.get('/plants', (req, res) => {
    const param = req.query.param;
    if (param === 'flowers') {
        const flowers = [
            { name: "Tulip", category: "Spring Flower" },
            { name: "Rose", category: "Perennial" },
            { name: "Daisy", category: "Wildflower" }
        ];
        res.json(flowers);
    } else if (param === 'trees') {
        const trees = [
            { name: "Oak", category: "Deciduous" },
            { name: "Pine", category: "Evergreen" },
            { name: "Birch", category: "Deciduous" }
        ];
        res.json(trees);
    } else {
        res.json([]);
    }
});

app.use((req, res) =>{
    res.sendFile(path.join(__dirname, 'views',  '404.html'))
})

app.listen(3010, () => {
    console.log('Server is running on port 3010');
});
